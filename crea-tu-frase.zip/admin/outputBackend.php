<?php 
/**
 * 
 * @package Crea Tu Frase
 * @subpackage M. Sufyan Shaikh
 * 
*/
 require_once plugin_dir_path(__FILE__) . './modules/getAllBuyers.php';