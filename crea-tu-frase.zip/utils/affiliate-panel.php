<?php
function chocoletras_affiliate()
{ ?>

    <section id="chocoletrasPlg" class="ctf_plugin_main">
        <div class="container-fluid">
            <div class="row justify-content-between">
                <div class="col-md-7 col-12 text-center mb-2">
                    <h1>Affiliate panel</h1>
                </div>
            </div>
        </div>
    </section>

<?php } ?>